import shutil,os,sys
def Main():
	f= open(os.path.join('/home/saurav/gem5/m5out',sys.argv[2]),"r")
	lines=f.readlines()
	f.close()
	count=0
	rline=[]
	for line in lines:
		if line.find("Begin Simulation Statistics")!=-1:
			count=count+1
		if count==3:
			rline.append(line)
	shutil.copy(os.path.join('/home/saurav/gem5/m5out',sys.argv[2]),'/home/saurav/gem5/Gem5ToMcPAT-Parser-master/Original')
	f= open(os.path.join('/home/saurav/gem5/m5out',sys.argv[2]),"w")
	f.writelines(rline)
	f.close()
	files=sys.argv[1:]
	for f in files:
		shutil.copy(os.path.join('/home/saurav/gem5/m5out',f),'/home/saurav/gem5/Gem5ToMcPAT-Parser-master/Automted')


Main()
				
			
		
