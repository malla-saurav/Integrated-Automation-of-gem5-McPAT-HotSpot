import os
import sys
import string
import fileinput


f= open(os.path.join('/home/saurav/gem5/configs/common','SysPaths.py'),"r")
lines=f.readlines()
for line in lines:
	if line.find("/home/saurav/IITG/full_sys_simu/system")!=-1:
		flag=1
	if line.find("/home/saurav/IITG/full_sys_simu/x86")!=-1:
		flag=2
f.close()
if flag==2 and int(sys.argv[1])==1:
	lines=[line.replace('/home/saurav/IITG/full_sys_simu/x86','/home/saurav/IITG/full_sys_simu/system') for line in lines]
	f= open(os.path.join('/home/saurav/gem5/configs/common','SysPaths.py'),"w")
	f.writelines(lines)
	f.close()
if flag==1 and int(sys.argv[1])==2:
	lines=[line.replace('/home/saurav/IITG/full_sys_simu/system','/home/saurav/IITG/full_sys_simu/x86') for line in lines]
	f= open(os.path.join('/home/saurav/gem5/configs/common','SysPaths.py'),"w")
	f.writelines(lines)
	f.close()
