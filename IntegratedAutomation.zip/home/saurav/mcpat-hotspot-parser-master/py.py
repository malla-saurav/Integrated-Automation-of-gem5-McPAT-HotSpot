import os,shutil
import sys
import string
import fileinput
import re

import os,sys,shutil,errno,re
def main():
	for i in range(1,int(sys.argv[1])+1):
		f=open(os.path.join('/home/saurav/gem5/mcpat/Output/{0}/{1}.txt'.format(sys.argv[2],i)),'r')
		lines=f.readlines()
		f.close()
		try:
			os.makedirs('/home/saurav/mcpat-hotspot-parser-master/{}'.format(sys.argv[2]))
		except OSError as e:
			if e.errno != errno.EEXIST:
				raise
		f=open(os.path.join('/home/saurav/mcpat-hotspot-parser-master/{0}/{1}.txt'.format(sys.argv[2],i)),'w')
		for line in lines:
			if line.find('Subthreshold Leakage with power gating = ')==-1:
				fl=re.findall(r'[-+]?\d*\.\d+|\d+',line)
				if len(fl)==1:
					fl1=float(fl[0])
				elif len(fl)==2:
					fl1=float(float(fl[0])*(10**int(fl[1])))
				line=line.split('=')[0]+'= '+str(fl1)+' W'
				f.write(line)
		f.close()
			
	
main()
