import shutil,os,sys
def Main():
	myfile=sys.argv[2]
	shutil.copy(os.path.join('/home/saurav/gem5/m5out',myfile),'/home/saurav/ProcessorAutomation/Original')
	f= open(os.path.join('/home/saurav/gem5/m5out',myfile),"r")
	lines=f.readlines()
	f.close()
	clines=lines
	count=0
	counter=0
	rline=[]
	os.makedirs('/home/saurav/ProcessorAutomation/Automted/{}'.format(myfile))
	shutil.copy(os.path.join('/home/saurav/ProcessorAutomation/Automted','Gem5ToMcPAT-Parser.py'),'/home/saurav/ProcessorAutomation/Automted/{}'.format(myfile))
	shutil.copy(os.path.join('/home/saurav/ProcessorAutomation/Automted','template.xml'),'/home/saurav/ProcessorAutomation/Automted/{}'.format(myfile))
	for line in lines:
		if line.find("Begin Simulation Statistics")!=-1:
			count=count+1
	for line in lines:
		if line.find("Begin Simulation Statistics")!=-1:
			counter=counter+1
		if counter>=3 and counter<count:
			rline.append(line)
			if line.find("End Simulation Statistics")!=-1:
				fi=''.join((str(counter-2),myfile))
				f=open(os.path.join('/home/saurav/gem5/m5out',fi),'w')
				f.writelines(rline)
				f.close()
				shutil.copy(os.path.join('/home/saurav/gem5/m5out',fi),'/home/saurav/ProcessorAutomation/Automted/{}'.format(myfile))
				os.remove(os.path.join('/home/saurav/gem5/m5out',fi))
				del rline[:]
	shutil.copy(os.path.join('/home/saurav/gem5/m5out',sys.argv[1]),'/home/saurav/ProcessorAutomation/Automted/{}'.format(myfile))


Main()
				
			
		
