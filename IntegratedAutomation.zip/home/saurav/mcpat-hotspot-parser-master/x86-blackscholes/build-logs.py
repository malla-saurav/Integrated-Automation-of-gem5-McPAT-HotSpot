import re
import sys

#regular expressions
ncores = re.compile('Total Cores: (\d+) cores')
nl2s = re.compile('Total L2s: (\d+)')
nl3s = re.compile('Total L3s: (\d+)')
nics = re.compile('Instruction Cache: (\d+)')
nifus = re.compile('Instruction Fetch Unit: (\d+)')
nbtbs = re.compile('Branch Target Buffer: (\d+)')
nbps = re.compile('Branch Predictor: (\d+)')
ngps = re.compile('Global Predictor: (\d+)')
nl1lps = re.compile('L1_Local Predictor: (\d+)')
nl2lps = re.compile('L2_Local Predictor: (\d+)')
ncs = re.compile('Chooser: (\d+)')
#nrs = re.compile('RAS: (\d+)')
nibs = re.compile('Instruction Buffer: (\d+)')
nids = re.compile('Instruction Decoder: (\d+)')
nrus = re.compile('Renaming Unit: (\d+)')
nfls = re.compile('Free List: (\d+)')
nfpfls = re.compile('FP Free List: (\d+)')
nlsus = re.compile('Load Store Unit: (\d+)')
ndcs = re.compile('Data Cache: (\d+)')
nits = re.compile('Itlb: (\d+)')
ndts = re.compile('Dtlb: (\d+)')
nrfs = re.compile('Register Files: (\d+)')
nirfs = re.compile('Integer RF: (\d+)')
nfrfs = re.compile('Floating Point RF: (\d+)')
niss = re.compile('Instruction Scheduler: (\d+)')
niws = re.compile('Instruction Window: (\d+)')


re_core = 'Core:\n'
re_l2 = 'L2\n'
re_l3='L3\n'
re_ics='Instruction Cache:\n'
re_ifu='Instruction Fetch Unit:\n'
re_btb='Branch Target Buffer:\n'
re_bp='Branch Predictor:\n'
re_gp='Global Predictor:\n'
re_l1lp='L1_Local Predictor:\n'
re_l2lp='L2_Local Predictor:\n'
re_c='Chooser:\n'
#re_r='RAS:\n'
re_ib='Instruction Buffer:\n'
re_id='Instruction Decoder:\n'
re_ru='Renaming Unit:\n'
re_fl='Free List:\n'
re_fpfl='FP Free List:\n'
re_lsu='Load Store Unit:\n'
re_dc='Data Cache:\n'
re_it='Itlb:\n'
re_dt='Dtlb:\n'
re_rf='Register Files:\n'
re_irf='Integer RF:\n'
re_frf='Floating Point RF:\n'
re_is='Instruction Scheduler:\n'
re_iw='Instruction Window:\n'
re_area = '\s*Area\s*=\s*([0-9.]*)\s*\w*\^\w*\n'
re_peak = '\s*Peak\s*Dynamic\s*=\s*([0-9.]*)\s*\w*\n'
re_subth = '\s*Subthreshold\s*Leakage\s*=\s*([0-9.]*)\s*\w*\n'
#re_subth_pwr_grat='\s*Subthreshold\s*Leakage\s*with\s*\s*power\s*grating\s*=\s*([0-9.]*)\s*\w*\n'
re_gate = '\s*Gate\s*Leakage\s*=\s*([0-9.]*)\s*\w*\n'
re_run = '\s*Runtime\s*Dynamic\s*=\s*([0-9.]*)\s*\w*\n'

core = re.compile(re_core+re_area+re_peak+re_subth+re_gate+re_run)
l2 = re.compile(re_l2+re_area+re_peak+re_subth+re_gate+re_run)
l3 = re.compile(re_l3+re_area+re_peak+re_subth+re_gate+re_run)
ics = re.compile(re_ics+re_area+re_peak+re_subth+re_gate+re_run)
ifu = re.compile(re_ifu+re_area+re_peak+re_subth+re_gate+re_run)
btb = re.compile(re_btb+re_area+re_peak+re_subth+re_gate+re_run)
bp = re.compile(re_bp+re_area+re_peak+re_subth+re_gate+re_run)
gp = re.compile(re_gp+re_area+re_peak+re_subth+re_gate+re_run)
l1lp = re.compile(re_l1lp+re_area+re_peak+re_subth+re_gate+re_run)
l2lp = re.compile(re_l2lp+re_area+re_peak+re_subth+re_gate+re_run)
r_c = re.compile(re_c+re_area+re_peak+re_subth+re_gate+re_run)
#r_r = re.compile(re_r+re_area+re_peak+re_subth+re_gate+re_run)
ib = re.compile(re_ib+re_area+re_peak+re_subth+re_gate+re_run)
r_id = re.compile(re_id+re_area+re_peak+re_subth+re_gate+re_run)
ru = re.compile(re_ru+re_area+re_peak+re_subth+re_gate+re_run)
fl = re.compile(re_fl+re_area+re_peak+re_subth+re_gate+re_run)
fpfl = re.compile(re_fpfl+re_area+re_peak+re_subth+re_gate+re_run)
lsu = re.compile(re_lsu+re_area+re_peak+re_subth+re_gate+re_run)
dc = re.compile(re_dc+re_area+re_peak+re_subth+re_gate+re_run)
it = re.compile(re_it+re_area+re_peak+re_subth+re_gate+re_run)
dt = re.compile(re_dt+re_area+re_peak+re_subth+re_gate+re_run)
rf = re.compile(re_rf+re_area+re_peak+re_subth+re_gate+re_run)
irf = re.compile(re_irf+re_area+re_peak+re_subth+re_gate+re_run)
frf = re.compile(re_frf+re_area+re_peak+re_subth+re_gate+re_run)
r_is = re.compile(re_is+re_area+re_peak+re_subth+re_gate+re_run)
iw = re.compile(re_iw+re_area+re_peak+re_subth+re_gate+re_run)

#OFFSET TO MULTPLY THE POWER TRACES TO INCREASE TEMPERATURE FASTER
OFFSET = 1.5
#FACTOR TO INCREASE THE NUMBER OF TRACES (INCREASE SIMULATION)
N_INC = 3

#READ ALL LINES OF FILE
def get_lines_of_file(fin):
	all_lines = fin.read()
	fin.close()
	return all_lines

#GET NUMBER OF ELEMENTS BASED ON DE "elem" re object.
#elem = regular expression object for number of elements (core, l2, etc...)
#all_lines = the file
def get_number_of_elems(elem, all_lines):
	m = elem.search(all_lines)
	if m:
		return int(m.group(1))
	else:
		return 1

#GET LIST OF POWER TRACES. THE LIST CONTAINS LISTS OF POWER TRACES FOR ALL ELEMENTS OF THE SAME TYPE (ex: core0, core1, ..., coren)
#elem = regular expression object for attributes of element "elem"
def get_power_traces(elem, number_of_elems, all_lines):
	p_traces = []
	for y in range(0,number_of_elems):
		p_traces.append([])
		
	traces_list = elem.findall(all_lines)
	for z in range(0,len(traces_list)):
		p_traces[z%number_of_elems].append(traces_list[z][4]);
	return p_traces

#WRITE HEADER TO PTRACE FILE (ONLY CORES AND L2S FOR NOW)
def write_header_ptrace(fout,number_of_cores,number_of_l2s,number_of_l3s,number_of_ic,a,b,c,d,e,f,g,_i,j,k,l,m,n,o,p,q,r,s,t,u,v):
	#WRITE CORES HEADERS
	for i in range(0,number_of_cores):
		fout.write('Core_'+str(i)+'\t')
	#WRITE L2s HEADERS
	for i in range(0,number_of_l2s):
		fout.write('L2_'+str(i)+'\t')
	for i in range(0,number_of_l3s):
		fout.write('L3_'+str(i)+'\t')
	for i in range(0,number_of_ic):
		fout.write('ICache_'+str(i)+'\t')
	for i in range(0,a):
		fout.write('IFU_'+str(i)+'\t')
	for i in range(0,b):
		fout.write('BTB_'+str(i)+'\t')
	for i in range(0,c):
		fout.write('BP_'+str(i)+'\t')
	for i in range(0,d):
		fout.write('GP_'+str(i)+'\t')
	for i in range(0,e):
		fout.write('L1LP_'+str(i)+'\t')
	for i in range(0,f):
		fout.write('L2LP_'+str(i)+'\t')
	for i in range(0,g):
		fout.write('Chooser_'+str(i)+'\t')
	#for i in range(0,h):
		#fout.write('RAS_'+str(i)+'\t')
	for i in range(0,_i):
		fout.write('IBuffer_'+str(_i)+'\t')
	for i in range(0,j):
		fout.write('IDecoder_'+str(i)+'\t')
	for i in range(0,k):
		fout.write('Runit_'+str(i)+'\t')
	for i in range(0,l):
		fout.write('Flist_'+str(i)+'\t')
	for i in range(0,m):
		fout.write('FPFlist_'+str(i)+'\t')
	for i in range(0,n):
		fout.write('LSU_'+str(i)+'\t')
	for i in range(0,o):
		fout.write('DCache_'+str(i)+'\t')
	for i in range(0,p):
		fout.write('Itlb_'+str(i)+'\t')
	for i in range(0,q):
		fout.write('Dtlb_'+str(i)+'\t')
	for i in range(0,r):
		fout.write('RFiles_'+str(i)+'\t')
	for i in range(0,s):
		fout.write('IntRF_'+str(i)+'\t')
	for i in range(0,t):
		fout.write('FloatRF_'+str(i)+'\t')
	for i in range(0,u):
		fout.write('Ischeduler_'+str(i)+'\t')
	for i in range(0,v):
		fout.write('IW_'+str(i)+'\t')
	#WRITE NEW LINE
	fout.write('\n')

#WRITE POWER TRACES TO PTRACE FILE (ONLY CORES AND L2S FOR NOW)
def write_traces_ptrace(fout,number_of_traces,p_traces_cores,p_traces_l2s,p_traces_l3s,a,b,c,d,e,f,g,h,_j,k,l,m,n,o,p,q,r,s,t,u,v,w):
	for i in range(0,number_of_traces):
		#write cores traces
		for j in range(0,len(p_traces_cores)):
			fout.write(str(float(p_traces_cores[j][i])*OFFSET) + '\t')
		#write l2s traces
		for j in range(0,len(p_traces_l2s)):
			fout.write(p_traces_l2s[j][i] + '\t')	
		for j in range(0,len(p_traces_l3s)):
			fout.write(p_traces_l3s[j][i] + '\t')	
		for j in range(0,len(a)):
			fout.write(a[j][i] + '\t')
		for j in range(0,len(b)):
			fout.write(b[j][i] + '\t')
		for j in range(0,len(c)):
			fout.write(c[j][i] + '\t')
		for j in range(0,len(d)):
			fout.write(d[j][i] + '\t')
		for j in range(0,len(e)):
			fout.write(e[j][i] + '\t')
		for j in range(0,len(f)):
			fout.write(f[j][i] + '\t')
		for j in range(0,len(g)):
			fout.write(g[j][i] + '\t')
		for j in range(0,len(h)):
			fout.write(h[j][i] + '\t')
		#for j in range(0,len(i)):
			#fout.write(i[j][i] + '\t')
		for j in range(0,len(_j)):
			fout.write(_j[j][i] + '\t')
		for j in range(0,len(k)):
			fout.write(k[j][i] + '\t')
		for j in range(0,len(l)):
			fout.write(l[j][i] + '\t')
		for j in range(0,len(m)):
			fout.write(m[j][i] + '\t')
		for j in range(0,len(n)):
			fout.write(n[j][i] + '\t')
		for j in range(0,len(o)):
			fout.write(o[j][i] + '\t')
		for j in range(0,len(p)):
			fout.write(p[j][i] + '\t')
		for j in range(0,len(q)):
			fout.write(q[j][i] + '\t')
		for j in range(0,len(r)):
			fout.write(r[j][i] + '\t')
		for j in range(0,len(s)):
			fout.write(s[j][i] + '\t')
		for j in range(0,len(t)):
			fout.write(t[j][i] + '\t')
		for j in range(0,len(u)):
			fout.write(u[j][i] + '\t')
		for j in range(0,len(v)):
			fout.write(v[j][i] + '\t')
		for j in range(0,len(w)):
			fout.write(w[j][i] + '\t')
		fout.write('\n')

#n_increase = number of times that the traces will be increased
def artificial_sim_increase(p_traces,number_of_traces,n_increase):
	for i in range(0,n_increase):
		for j in range(0,len(p_traces)):
			last_trace = p_traces[j][-1]
			#increase traces
			for k in range(0,number_of_traces):
				p_traces[j].append(str(float(p_traces[j][k])+float(last_trace)))

all_p_traces_cores = []

last_parameter = sys.argv[-1]
if last_parameter.split('.')[-1] != 'ptrace':
    raise ValueError('DANIEL ERROR(0): Last parameter should be a ptrace extension file')
else:

    #READ ALL INPUT MCPAT LOG FILES AND GET THE CORES TRACES TOGETHER (ONLY THE CORES EXCITED BY THE SIMULATION (CORE_O))
    for i in range(1,len(sys.argv)-1):
	fin = open(sys.argv[i],'r')

	all_lines = get_lines_of_file(fin)

	number_of_cores = get_number_of_elems(ncores,all_lines)

	number_of_l2s = get_number_of_elems(nl2s,all_lines)
	
	number_of_l3s = get_number_of_elems(nl3s,all_lines)

	a = get_number_of_elems(nics,all_lines)

	b = get_number_of_elems(nifus,all_lines)

	c = get_number_of_elems(nbtbs,all_lines)

	d = get_number_of_elems(nbps,all_lines)

	e = get_number_of_elems(ngps,all_lines)

	f = get_number_of_elems(nl1lps,all_lines)

	g = get_number_of_elems(nl2lps,all_lines)

	h = get_number_of_elems(ncs,all_lines)

	#i = get_number_of_elems(nrs,all_lines)

	j = get_number_of_elems(nibs,all_lines)

	k = get_number_of_elems(nids,all_lines)

	l = get_number_of_elems(nrus,all_lines)

	m = get_number_of_elems(nfls,all_lines)

	n = get_number_of_elems(nfpfls,all_lines)

	o = get_number_of_elems(nlsus,all_lines)

	p = get_number_of_elems(ndcs,all_lines)

	q = get_number_of_elems(nits,all_lines)

	r = get_number_of_elems(ndts,all_lines)

	s = get_number_of_elems(nrfs,all_lines)

	t = get_number_of_elems(nirfs,all_lines)

	u = get_number_of_elems(nfrfs,all_lines)

	v = get_number_of_elems(niss,all_lines)

	w = get_number_of_elems(niws,all_lines)
	
	p_traces_cores = get_power_traces(core,number_of_cores,all_lines)

	p_traces_l2s = get_power_traces(l2,number_of_l2s,all_lines)

	p_traces_l3s = get_power_traces(l3,number_of_l3s,all_lines)

	pa = get_power_traces(ics,a,all_lines)

	pb = get_power_traces(ifu,b,all_lines)

	pc = get_power_traces(btb,c,all_lines)

	pd = get_power_traces(bp,d,all_lines)

	pe = get_power_traces(gp,e,all_lines)

	pf = get_power_traces(l1lp,f,all_lines)

	pg = get_power_traces(l2lp,g,all_lines)

	ph = get_power_traces(r_c,h,all_lines)

	#pi = get_power_traces(r_r,i,all_lines)

	pj = get_power_traces(ib,j,all_lines)

	pk = get_power_traces(r_id,k,all_lines)

	pl = get_power_traces(ru,l,all_lines)

	pm = get_power_traces(fl,m,all_lines)

	pn = get_power_traces(fpfl,n,all_lines)

	po = get_power_traces(lsu,o,all_lines)

	pp = get_power_traces(dc,p,all_lines)

	pq = get_power_traces(it,q,all_lines)

	pr = get_power_traces(dt,r,all_lines)

	ps = get_power_traces(rf,s,all_lines)

	pt = get_power_traces(irf,t,all_lines)

	pu = get_power_traces(frf,u,all_lines)

	pv = get_power_traces(r_is,v,all_lines)

	pw = get_power_traces(iw,w,all_lines)

	all_p_traces_cores.append(p_traces_cores[0])

    artificial_sim_increase(all_p_traces_cores,len(all_p_traces_cores[0]),N_INC)
    artificial_sim_increase(p_traces_l2s,len(p_traces_l2s[0]),N_INC)
    artificial_sim_increase(p_traces_l3s,len(p_traces_l3s[0]),N_INC)
    artificial_sim_increase(pa,len(pa[0]),N_INC)
    artificial_sim_increase(pb,len(pb[0]),N_INC)
    artificial_sim_increase(pc,len(pc[0]),N_INC)
    artificial_sim_increase(pd,len(pd[0]),N_INC)
    artificial_sim_increase(pe,len(pe[0]),N_INC)
    artificial_sim_increase(pf,len(pf[0]),N_INC)
    artificial_sim_increase(pg,len(pg[0]),N_INC)
    artificial_sim_increase(ph,len(ph[0]),N_INC)
    #artificial_sim_increase(pi,len(pi[0]),N_INC)
    artificial_sim_increase(pj,len(pj[0]),N_INC)
    artificial_sim_increase(pk,len(pk[0]),N_INC)
    artificial_sim_increase(pl,len(pl[0]),N_INC)
    artificial_sim_increase(pm,len(pm[0]),N_INC)
    artificial_sim_increase(pn,len(pn[0]),N_INC)
    artificial_sim_increase(po,len(po[0]),N_INC)
    artificial_sim_increase(pp,len(pp[0]),N_INC)
    artificial_sim_increase(pq,len(pq[0]),N_INC)
    artificial_sim_increase(pr,len(pr[0]),N_INC)
    artificial_sim_increase(ps,len(ps[0]),N_INC)
    artificial_sim_increase(pt,len(pt[0]),N_INC)
    artificial_sim_increase(pu,len(pu[0]),N_INC)
    artificial_sim_increase(pv,len(pv[0]),N_INC)
    artificial_sim_increase(pw,len(pw[0]),N_INC)

    #CALCULATE NUMBER OF TRACES TO BE PRINTED IN CASE OF FILES DIFFER (get smaller)
    number_of_traces = len(all_p_traces_cores[0])
    for p_traces_cores in all_p_traces_cores:
	if len(p_traces_cores) < number_of_traces:
		number_of_traces = len(p_traces_cores)


    fout = open(sys.argv[-1],'w')

    #WRITE HEADER TO PTRACE FILE
    #last parameter is the number of l2s. In case of 8 cores I have been using 2 l2s
    write_header_ptrace(fout,len(all_p_traces_cores),1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1)
    write_traces_ptrace(fout,number_of_traces,all_p_traces_cores,p_traces_l2s,p_traces_l3s,pa,pb,pc,pd,pe,pf,pg,ph,pj,pk,pl,pm,pn,po,pp,pq,
pr,ps,pt,pu,pv,pw)

    #WRITE POWER TRACE
    fout.close()



