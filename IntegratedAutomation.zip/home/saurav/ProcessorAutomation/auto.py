#This Script is the Integration of the three Tool Named gem5+mcPAT+Hotspot
#gem5 is a System Simulation Tool
#This Script Uses the 6 PARSEC Program to run the simulation in the Integration of this Three Tools
#The Description Of Each Function is Given in the Document of this Script.





import os,sys,shutil,fileinput,errno,matplotlib.pyplot as plt,re




#Function to Choose the PARSEC Program and ISA and the Output Choice Type
def menu():
	print("Choose The Benchmark(Parsec) Number from the following benchmarks:-")
	print("1.blackscholes")
	print("2.x264")
	print("3.vips")
	print("4.bodytrack")
	print("5.swaptions")
	print("6.streamcluster")
	print("")
	benchNo=int(raw_input("Enter the Benchmark Number:-"))
	print("")
	print("Choose The ISA Number You Wants to Use for Simulation from the following ISA's:-")
	print("1.ALPHA")
	print("2.X86")
	print("")
	ISANo=int(raw_input("Enter the ISA Number:-"))
	print("")
	print("Following are the Choice for the Output After the Gem5:-")
	print("1.Sample the ROI(Region of Interest) in Stats file")
	print("2.Take the Output as Whole for ROI.")
	choice=int(raw_input("Enter the Choice for Output:-")) 
	return (benchNo,ISANo,choice)




#Function to create the names of Different files according to the Choice given by the User in the menu Function. 
def createFileName(benchNo,ISANo):
	File={
		1:"blackscholes",
		2:"x264",
		3:"vips",
		4:"bodytrack",
		5:"swaptions",
		6:"streamcluster"
	}
	ISA={
		1:"alpha",
		2:"x86"
	}
	scriptfile=''.join((File.get(benchNo,"nothing"),'_1c_simsmall.rcS'))	#Since we are using simsmall with 1 thread the function name is appended with _1c_simsmall.rcS
	configfile=''.join((ISA.get(ISANo,"nothing"),File.get(benchNo,"nothing"),'Config.json'))
	statsfile=''.join((ISA.get(ISANo,"nothing"),File.get(benchNo,"nothing"),'Stats.txt'))
	directory='-'.join((ISA.get(ISANo,"nothing"),File.get(benchNo,"nothing")))
	return (scriptfile,configfile,statsfile,directory)





#This Function is to change the Script file according to the Choice whether We Wants to get the sampled ROI as Output or Whole ROI.
def changeScriptfile(scriptfile,choice):
	f= open(os.path.join('/home/saurav/gem5','{}'.format(scriptfile)),"r") 	#Please mention Here the Path Where you have kept the .rcS file in your PC
	lines=f.readlines()
	for line in lines:
		if line.find("#m5 dumpresetstats")!=-1:
			flag=1
		if line.find("m5 dumpresetstats")!=-1 and line.find("#m5 dumpresetstats")==-1:
			flag=2
	f.close()
	if flag==1 and choice==1:
		lines=[line.replace('#m5 dumpresetstats','m5 dumpresetstats') for line in lines]
		f= open(os.path.join('/home/saurav/gem5','{}'.format(scriptfile)),"w")
		f.writelines(lines)
		f.close()
	if flag==2 and choice==2:
		lines=[line.replace('m5 dumpresetstats','#m5 dumpresetstats') for line in lines]
		f= open(os.path.join('/home/saurav/gem5','{}'.format(scriptfile)),"w")
		f.writelines(lines)
		f.close()






#This Function is for changing the path of the Syspaths.py in gem5 for Different ISA. This Path tells the gem5 from where it needs to take the ISA Disk Image in the PAC.
def changeSysPath(ISANo):
	f= open(os.path.join('/home/saurav/gem5/configs/common','SysPaths.py'),"r")
	lines=f.readlines()
	for line in lines:
		if line.find("/home/saurav/IITG/full_sys_simu/system")!=-1: #This is the path for the disk and binaries of ALPHA in my PC, You should Set yours accordingly.
			flag=1
		if line.find("/home/saurav/IITG/full_sys_simu/x86")!=-1:    #This is the path for the disk and binaries of X86 in my PC, You should Set yours accordingly. 
			flag=2
	f.close()
	if flag==2 and ISANo==1:
		lines=[line.replace('/home/saurav/IITG/full_sys_simu/x86','/home/saurav/IITG/full_sys_simu/system') for line in lines]# This line is replacing the X86 path by ALPHA path for Disk and Binaries in my PC You Should Set Yours.
		f= open(os.path.join('/home/saurav/gem5/configs/common','SysPaths.py'),"w")   #It is the of the path of the Syspaths.py of gem5 in my PC
		f.writelines(lines)
		f.close()
	if flag==1 and ISANo==2:
		lines=[line.replace('/home/saurav/IITG/full_sys_simu/system','/home/saurav/IITG/full_sys_simu/x86') for line in lines]  # This line is replacing the ALPHA path by X86 path for Disk and Binaries in my PC You Should Set Yours.
		f= open(os.path.join('/home/saurav/gem5/configs/common','SysPaths.py'),"w")  #It is the of the path of the Syspaths.py of gem5 in my PC
		f.writelines(lines)
		f.close()




#This Function runs the PARSEC on gem5 according to the Choice You have made in the Menu.
def runGem5(scriptfile,statsfile,configfile,ISANo):
	ISAName=''
	if ISANo==1:
		ISAName='ALPHA'
	elif ISANo==2:
		ISAName='X86'
	os.chdir("/home/saurav/gem5")
	os.system("./build/{}/gem5.opt --stats-file={} --json-config={} configs/example/fs.py --script=./{} --caches --l2cache".format(ISAName,statsfile,configfile,scriptfile))







#This Function Automatically Extracts the Region Of Interest(ROI) from the Stats.txt file the gem5 generated from its simulation of the above function.
# If the Choice is given for the Sampled ROI then this function Automatically extracts the Section 3 of the stats file to the Second last section of the Stats file to different text files for different section in the location ProcessorAutomation/Automated/ISA-programName Location 
# For Full ROI It Extracts the ROI to a single file named full.txt in the same above location.
#Also a Original copy of the stats.txt file before extraction by this function is also saved in ProcessorAutomation/Original/ISA-programName
def exctractROI(configfile,statsfile,directory,choice):
	myfile=statsfile
	shutil.copy(os.path.join('/home/saurav/gem5/m5out',myfile),'/home/saurav/ProcessorAutomation/Original') # Provide the First Location befor comma in this function where the stats.txt file of the Simualtion is Present and the Second Location is Where You Wnts to Copy the Original file in Your PC
	f= open(os.path.join('/home/saurav/gem5/m5out',myfile),"r") #Replace the Locaion Where the stats.txt file is Present in your PC.
	lines=f.readlines()
	f.close()
	clines=lines
	count=0
	counter=0
	rline=[]
	sendCount=0
	statfiles=[]
	try:
		os.makedirs('/home/saurav/ProcessorAutomation/Automated/{}'.format(directory)) # This is the Command to Create a directory to store all the text file after extraction from the ROI , You Should Provide Your Own Location.
	except OSError as e:
		if e.errno != errno.EEXIST:
			raise
	shutil.copy(os.path.join('/home/saurav/ProcessorAutomation/Automated','Gem5ToMcPAT-Parser.py'),'/home/saurav/ProcessorAutomation/Automated/{}'.format(directory)) #Copying the Parser to the Directory You have just created for storing the text file, You should Provide the Location Where is in your PC the Parser is Actually present. 
	shutil.copy(os.path.join('/home/saurav/ProcessorAutomation/Automated','template.xml'),'/home/saurav/ProcessorAutomation/Automated/{}'.format(directory)) #Copying the template file Which will be used to generate the mcPAT input to the Above Directory, Location Should be Provided for Your Own PC. 
	for line in lines:
		if line.find("Begin Simulation Statistics")!=-1:
			count=count+1
	for line in lines:
		if line.find("Begin Simulation Statistics")!=-1:
			counter=counter+1
		if counter>=3 and counter<count:
			rline.append(line)
			if line.find("End Simulation Statistics")!=-1:
				if choice==1:
					fi=''.join((str(counter-2),myfile))
				elif choice==2:
					fi='-'.join(('full',myfile))
				statfiles.append(fi)
				f=open(os.path.join('/home/saurav/gem5/m5out',fi),'w') #Creating  temporary text file to store the extraction in the directory where the stats.txt file is present for simplicity, later we have moved the files in the Directory we have created Just now above. 
				f.writelines(rline)
				f.close()
				shutil.copy(os.path.join('/home/saurav/gem5/m5out',fi),'/home/saurav/ProcessorAutomation/Automated/{}'.format(directory)) # Here We are Copying the newly extracted text files by this function  to the Directpory ISA-programName we have just created.
				os.remove(os.path.join('/home/saurav/gem5/m5out',fi)) #remove the files after \copying.
				del rline[:]
				sendCount=sendCount+1
	shutil.copy(os.path.join('/home/saurav/gem5/m5out',configfile),'/home/saurav/ProcessorAutomation/Automated/{}'.format(directory)) #copy the config.json file to the Same Directory.
	return (sendCount,statfiles)





#This Function is used to convet the gem5 Output to McPAT input by using the text files extracted and the config.json files and the template.xml file. We need to go to the Directory Where we have all this Files in the terminal, But in this Automation it will Occur Automatically.
def convertGem5ToMcPATInput(directory,sendCount,statfiles,configfile):
	os.chdir('/home/saurav/ProcessorAutomation/Automated/{}'.format(directory)) # Location where all the files of extracted ROI and template.xml and Parser Script is Present.
	if sendCount==1:
		os.system("python Gem5ToMcPAT-Parser.py -c {} -s {} -t template.xml -o full.xml".format(configfile,statfiles[sendCount-1]))
	else:
		for i in range(sendCount):
			os.system("python Gem5ToMcPAT-Parser.py -c {} -s {} -t template.xml -o {}.xml".format(configfile,statfiles[i],i+1))




#This Function is used to Shift all the McPAT input files from the directory where we have just converted the Output of gem5 to input of McPAT to the McPAT Directory for smooth Running of the McPAT. 
def shiftMcPATInputFilesToMcPATDirectory(sendCount,directory):
	os.chdir('/home/saurav/gem5/mcpat')  #change the Directory to the Directory of mcpat
	try:
		os.makedirs('/home/saurav/gem5/mcpat/{}'.format(directory)) #make a directory with same name as ISA-programName inside the mcpat directory.
	except OSError as e:
		if e.errno != errno.EEXIST:
			raise
	os.chdir('/home/saurav/ProcessorAutomation/Automated/{}'.format(directory))  #Now change the directory to the diectory where You have created the mcpat input files.
	if sendCount==1:
		shutil.copy('full.xml','/home/saurav/gem5/mcpat/{}'.format(directory)) #give the location where is your mcpat directory
		os.remove('full.xml')
	else:
		for i in range(1,sendCount+1):
			shutil.copy('{}.xml'.format(i),'/home/saurav/gem5/mcpat/{}'.format(directory))	#same as last comment
			os.remove('{}.xml'.format(i))




#This Function is Used for Running the McPAT in terminal
# We have Already have taken the Output of terminal to some text File.
def runMcPAT(sendCount,directory):
	try:
		os.makedirs('/home/saurav/gem5/mcpat/Output/{}'.format(directory)) #make a directory at McPAT Output Directory for storing the Output
	except OSError as e:
		if e.errno != errno.EEXIST:
			raise
	os.chdir('/home/saurav/gem5/mcpat') # Change the Directory to mcpat.
	if sendCount==1:
		os.system('./mcpat -infile {0}/full.xml -print_level 5 -opt_for_clk 1 > /home/saurav/gem5/mcpat/Output/{0}/full.txt'.format(directory))	#Store the Output to the Desired Location
	else:
		for i in range(1,sendCount+1):
			os.system('./mcpat -infile {0}/{1}.xml -print_level 5 -opt_for_clk 1 > /home/saurav/gem5/mcpat/Output/{0}/{1}.txt'.format(directory,i)) #same as last Comment



#This Function is Used for extracting the Runtime Dynamic of the McPAT Output of the Processor.
def extractRuntimeDynamic(directory,sendCount):
	lRunDynamic=[]
	if sendCount==1:
		f=open(os.path.join('/home/saurav/gem5/mcpat/Output/{}'.format(directory),'full.txt'),'r') # Give the Location where You have Stored the Output of McPAT
		lines=f.readlines()
		for line in lines:
			if line.find('Runtime Dynamic')!=-1:
				fl=re.findall(r'[-+]?\d*\.\d+|\d+',line)
				if len(fl)==1:
					fl1=float(fl[0])
				elif len(fl)==2:
					fl1=float(float(fl[0])*(10**int(fl[1])))
					lRunDynamic.append(fl1)
					break
		f.close()
	else:
		for i in range(1,sendCount+1):
			f=open(os.path.join('/home/saurav/gem5/mcpat/Output/{}'.format(directory),'{}.txt'.format(i)),'r')#same as Last Comment
			lines=f.readlines()
			for line in lines:
				if line.find('Runtime Dynamic')!=-1:
					fl=re.findall(r'[-+]?\d*\.\d+|\d+',line)
					if len(fl)==1:
						fl1=float(fl[0])
					elif len(fl)==2:
						fl1=float(float(fl[0])*(10**int(fl[1])))
					lRunDynamic.append(fl1)
					break
			f.close()
	return(lRunDynamic)





#This Function is for Normaliazing the Runtime Dynamic Value to 0-1
def normalizeRuntimeDynamicData(lRunDynamic,directory):
	if max(lRunDynamic)-min(lRunDynamic)==0:
		f=open(os.path.join('/home/saurav/gem5/mcpat/Output/{}'.format(directory),'fullROI{}.txt'.format(directory)),'w')
		lRunDynamicNorm=lRunDynamic
		f.write('Full ROI -- Runtime Dynamic={0}  --  Normalized Runtime Dynamic={1}'.format(lRunDynamic[0],lRunDynamicNorm[0]))
		f.close()
		return (lRunDynamicNorm)
	lRunDynamicNorm= [float(x-min(lRunDynamic))/(max(lRunDynamic)-min(lRunDynamic)) for x in lRunDynamic]
	f=open(os.path.join('/home/saurav/gem5/mcpat/Output/{}'.format(directory),'{0}.txt'.format(directory)),'w')
	for i in range(1,len(lRunDynamic)+1):
		f.write('Sample {0} -- Runtime Dynamic={1}  -- Normalized Runtime Dynamic={2}'.format(i,lRunDynamic[i-1],lRunDynamicNorm[i-1]))
		f.write('\n')
	f.close()
	return (lRunDynamicNorm)



# This function is Used for Plotting the Graph Between different Intervals in ROI against Runtime Synamic Of the Processor
def plotGraph(lRunDynamicNorm,directory):
	x=[i for i in range(1,len(lRunDynamicNorm)+1)]
	y=[i for i in lRunDynamicNorm]
	plt.plot(x, y, color='green', linestyle='--', linewidth = 1,marker='o', markerfacecolor='blue', markersize=8) 
	#yax=len(lRunDynamicNorm)
	#plt.axis(0,1,0,len(lRunDynamicNorm))
	plt.xlabel('Sample Number')
	plt.ylabel('Runtime Dynamic')
	plt.title('{} Runtime Dynamic Plotting of McPAT'.format(directory))
	plt.savefig('/home/saurav/gem5/mcpat/Output/{0}/{0}.pdf'.format(directory))
	plt.show()


#This Function is used for Converting the McPAT Output to HotSpot Input compatible form
def convertMcPATOut(sendCount,directory):
	if sendCount==1:
		f=open(os.path.join('/home/saurav/gem5/mcpat/Output/{}/full.txt'.format(directory)),'r') #Location where is Your Output Files of McPAT is there
		lines=f.readlines()
		f.close()
		fl1=0
		try:
			os.makedirs('/home/saurav/mcpat-hotspot-parser-master/{}'.format(directory)) #Give here the Location Where is your mcpat to hotspot parser is there.
		except OSError as e:
			if e.errno != errno.EEXIST:
				raise
		f=open(os.path.join('/home/saurav/mcpat-hotspot-parser-master/{}/full.txt'.format(directory)),'w') #Same as last comment
		for line in lines:
			if line.find("Subthreshold Leakage with power gating = ")==-1:
				if line.find(" = ")!=-1 and line.find("Area")==-1:
					fl=re.findall(r'[-+]?\d*\.\d+|\d+',line)
					if len(fl)==1:
						fl1=float(fl[0])
					elif len(fl)==2:
						fl1=float(float(fl[0])*(10**int(fl[1])))
					line=line.split('=')[0]+'= '+str(fl1)+' W\n'
				f.write(line)
		f.close()
	else:
		for i in range(1,sendCount+1):
			f=open(os.path.join('/home/saurav/gem5/mcpat/Output/{0}/{1}.txt'.format(directory,i)),'r') #same as last comment
			lines=f.readlines()
			f.close()
			fl1=0
			try:
				os.makedirs('/home/saurav/mcpat-hotspot-parser-master/{}'.format(directory)) #same as last comment
			except OSError as e:
				if e.errno != errno.EEXIST:
					raise
			f=open(os.path.join('/home/saurav/mcpat-hotspot-parser-master/{0}/{1}.txt'.format(directory,i)),'w') #same as last comment
			for line in lines:
				if line.find("Subthreshold Leakage with power gating = ")==-1:
					if line.find(" = ")!=-1 and line.find("Area")==-1:
						fl=re.findall(r'[-+]?\d*\.\d+|\d+',line)
						if len(fl)==1:
							fl1=float(fl[0])
						elif len(fl)==2:
							fl1=float(float(fl[0])*(10**int(fl[1])))
						line=line.split('=')[0]+'= '+str(fl1)+' W\n'
					f.write(line)
			f.close()	




#Convert the McPAT Output to the Hotspot Input  by Modified Parser.
def McPATOutToHotspotIn(sendCount,directory):
	os.chdir('/home/saurav/mcpat-hotspot-parser-master/{}'.format(directory))
	shutil.copy(os.path.join('/home/saurav/mcpat-hotspot-parser-master','build-logs.py'),'/home/saurav/mcpat-hotspot-parser-master/{}'.format(directory))
	if sendCount==1:
		os.system('python build-logs.py full.txt full.ptrace')
	else:
		for i in range(1,sendCount+1):
			os.system('python build-logs.py {0}.txt {0}.ptrace'.format(i))




def shiftHotspotInputFilesToHotspotDirectory(sendCount,directory):
	try:
		os.makedirs('/home/saurav/IITG/hotspot/{}'.format(directory)) #Make a directory to the Hotspot Directory
	except OSError as e:
		if e.errno != errno.EEXIST:
			raise
	os.chdir('/home/saurav/mcpat-hotspot-parser-master/{}'.format(directory)) #change the directory where the Hotspot Ptrace files you have generated 
	if sendCount==1:
		shutil.copy(os.path.join('/home/saurav/mcpat-hotspot-parser-master/{}'.format(directory),'full.ptrace'),'/home/saurav/IITG/hotspot/{}'.format(directory))  #Copy the Files to Hotspot Directory
		os.remove('full.ptrace')
	else:
		for i in range(1,sendCount+1):
			shutil.copy(os.path.join('/home/saurav/mcpat-hotspot-parser-master/{}'.format(directory),'{}.ptrace'.format(i)),'/home/saurav/IITG/hotspot/{}'.format(directory))   #same as last comment
			os.remove('{}.ptrace'.format(i))





#Run Hotspot in Terminal
def runHotspot(sendCount,directory):
	os.chdir('/home/saurav/IITG/hotspot')
	if sendCount==1:
		os.system('./hotspot -c hotspot.config -f full.flp -p /home/saurav/IITG/hotspot/{0}/full.ptrace -steady_file /home/saurav/IITG/hotspot/{0}/full.steady -model_type grid -grid_steady_file /home/saurav/IITG/hotspot/{0}/full.grid.steady'.format(directory))
		os.system('./grid_thermal_map.pl full.flp /home/saurav/IITG/hotspot/{0}/full.grid.steady > /home/saurav/IITG/hotspot/{0}/full.svg'.format(directory))
	else:
		for i in range(1,sendCount+1):
			os.system('./hotspot -c hotspot.config -f full.flp -p /home/saurav/IITG/hotspot/{0}/{1}.ptrace -steady_file /home/saurav/IITG/hotspot/{0}/{1}.steady -model_type grid -grid_steady_file /home/saurav/IITG/hotspot/{0}/{1}.grid.steady'.format(directory,i))
			os.system('./grid_thermal_map.pl full.flp /home/saurav/IITG/hotspot/{0}/{1}.grid.steady > /home/saurav/IITG/hotspot/{0}/{1}.svg'.format(directory,i))






#Main() is connecting all the function in the script also making the flow.
def Main():
	(benchNo,ISANo,choice)=menu()
	(scriptfile,configfile,statsfile,directory)=createFileName(benchNo,ISANo)
	if directory.find('nothing')!=-1:
		print("Wrong Choice of ISA/benchmark, Please Enter Again...")
		sys.exit()
	
	changeScriptfile(scriptfile,choice)
	changeSysPath(ISANo)
	runGem5(scriptfile,statsfile,configfile,ISANo)
	statfiles=[]
	(sendCount,statfiles)=exctractROI(configfile,statsfile,directory,choice)
	convertGem5ToMcPATInput(directory,sendCount,statfiles,configfile)
	shiftMcPATInputFilesToMcPATDirectory(sendCount,directory)
	runMcPAT(sendCount,directory)
	os.chdir('/home/saurav')
	lRunDynamic=extractRuntimeDynamic(directory,sendCount)
	lRunDynamicNorm=normalizeRuntimeDynamicData(lRunDynamic,directory)
	plotGraph(lRunDynamicNorm,directory)
	convertMcPATOut(sendCount,directory)
	McPATOutToHotspotIn(sendCount,directory)
	shiftHotspotInputFilesToHotspotDirectory(sendCount,directory)
	runHotspot(sendCount,directory)
	os.chdir('/home/saurav')
	os.system('/bin/bash')

Main()


				




		
